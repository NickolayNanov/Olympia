﻿namespace Olympia.Services.Data
{
    public interface ISettingsService
    {
        int GetCount();
    }
}
