﻿namespace Olympia.Services.Utilities
{
    public static class Constants
    {
        public const string CloudinaryCloudName = "olympiacloudinary";

        public const string CloudinaryApiKey = "965922191253957";

        public const string CloudinaryApiSecret = "Gu07uBI4NqBDV4IRQmOVypXGvt0";

        public const string CloudinaryEnvironmentVariable = "CLOUDINARY_URL=cloudinary://965922191253957:Gu07uBI4NqBDV4IRQmOVypXGvt0@olympiacloudinary/";

        public const string CloudinaryInvalidUrl = "https://res.cloudinary.com/vallec/image/upload/v1561301682/No_image_available_zvvugj.png";
    }
}