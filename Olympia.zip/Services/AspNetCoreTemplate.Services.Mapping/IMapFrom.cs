﻿namespace Olympia.Services.Mapping
{
    // ReSharper disable once UnusedTypeParameter
    public interface IMapFrom<T>
    {
    }
}
