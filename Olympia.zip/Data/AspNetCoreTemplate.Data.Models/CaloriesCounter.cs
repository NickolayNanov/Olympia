﻿namespace Olympia.Data.Domain
{
    public class CaloriesCounter
    {
        //TODO: Implement
    }
}
