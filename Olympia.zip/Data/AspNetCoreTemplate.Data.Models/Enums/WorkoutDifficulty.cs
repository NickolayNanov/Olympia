﻿namespace Olympia.Data.Domain.Enums
{
    public enum WorkoutDifficulty
    {
        Beginner = 1,
        Intermediate = 2,
        Advanced = 3,
    }
}
