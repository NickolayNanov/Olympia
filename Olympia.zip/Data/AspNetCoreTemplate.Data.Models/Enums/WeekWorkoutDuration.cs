﻿namespace Olympia.Data.Domain.Enums
{
    public enum WeekWorkoutDuration
    {
        Four = 1,
        Six = 2,
        Eight = 3,
    }
}
