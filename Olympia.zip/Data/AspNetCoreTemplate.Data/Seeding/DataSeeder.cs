﻿namespace Olympia.Data.Seeding
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.AspNetCore.Identity;
    using Microsoft.EntityFrameworkCore;
    using Olympia.Data.Domain;

    public class DataSeeder
    {
        

        public DataSeeder()
        {
            
        }

        // public async void SeedAsync(DbContextOptionsBuilder<OlympiaDbContext> options)
        // {
        //      this.context = new OlympiaDbContext(options.Options);
           
        //      List<Article> list = this.GetArticles();
        //      List<ParentCategory> parentCategories = this.GetCategories();
           
        //      this.context.Articles.AddRange(list);
        //      this.context.ParentCategories.AddRange(parentCategories);
           
        //      await this.context.SaveChangesAsync();
        // }

        // private List<ParentCategory> GetCategories()
        // {
        //     return new List<ParentCategory>
        //     {
        //         new ParentCategory
        //         {
        //             Name = "Equipment",
        //             ChildCategories = new HashSet<ChildCategory>
        //             {
        //                 new ChildCategory
        //                 {
        //                     Name = "Fitness",
        //                     Description = "Equipment for indoor trainees",
        //                     ImageUrl = "https://www.google.com/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&ved=2ahUKEwjY4ISekYfjAhVP6qQKHdOXBM0QjRx6BAgBEAU&url=https%3A%2F%2Fwww.repfitness.com%2Frep-rubber-grip-hex-dumbbells&psig=AOvVaw3f_sDFyIa6A8TOWHDwJbmA&ust=1561638053616619",
        //                 },
        //                 new ChildCategory
        //                 {
        //                     Name = "Outside",
        //                     Description = "Equipment for outdoor trainees",
        //                     ImageUrl = "https://www.google.com/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&ved=2ahUKEwjE-YHukYfjAhXLzKQKHa2xDVIQjRx6BAgBEAU&url=https%3A%2F%2Fxorbars.co.uk%2Fproduct%2F3-5ft-pull-up-bar-or-back-row-bar%2F&psig=AOvVaw3Qd01jbAcI4fOUBm8G0Cuh&ust=1561638221316113",
        //                 },
        //             },
        //         },
        //         new ParentCategory
        //         {
        //             Name = "Supplements",
        //             ChildCategories = new HashSet<ChildCategory>
        //             {
        //                 new ChildCategory
        //                 {
        //                     Name = "Bio",
        //                     Description = "Equipment for indoor trainees",
        //                     ImageUrl = "https://www.google.com/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&ved=2ahUKEwjf-ImdkofjAhXExqQKHUC4Dr8QjRx6BAgBEAU&url=https%3A%2F%2Fwww.indiamart.com%2Fproddetail%2Foriginal-supplements-12843758612.html&psig=AOvVaw2DI232M9SPJobnX9oTQtga&ust=1561638315134665",
        //                 },
        //                 new ChildCategory
        //                 {
        //                     Name = "Ordinary",
        //                     Description = "Equipment for outdoor trainees",
        //                     ImageUrl = "https://www.google.com/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&ved=2ahUKEwjf-ImdkofjAhXExqQKHUC4Dr8QjRx6BAgBEAU&url=https%3A%2F%2Fwww.indiamart.com%2Fproddetail%2Foriginal-supplements-12843758612.html&psig=AOvVaw2DI232M9SPJobnX9oTQtga&ust=1561638315134665",
        //                 },
        //             },
        //         },
        //     };
        // 
        // }

        // private List<Article> GetArticles()
        // {
        //     var user = this.context.Users.Find("864fc7a6-321f-4354-841f-ab5d34188402");
           
        //     return new List<Article>
        //     {
        //         new Article
        //         {
        //             Title = "How to get abs in 3 weeks!",
        //             Content = "orem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. ",
        //             AuthorId = "864fc7a6-321f-4354-841f-ab5d34188402",
        //         },
        //         new Article
        //         {
        //             Title = "How to get Biceps in 3 weeks!",
        //             Content = "orem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. ",
        //             AuthorId = "864fc7a6-321f-4354-841f-ab5d34188402",
        //         },
        //         new Article
        //         {
        //             Title = "How to get ripped in 3 weeks!",
        //             Content = "orem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. ",
        //             AuthorId = "864fc7a6-321f-4354-841f-ab5d34188402",
        //         },
        //         new Article
        //         {
        //             Title = "How to get stronger in 3 weeks!",
        //             Content = "orem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. ",
        //             AuthorId = "864fc7a6-321f-4354-841f-ab5d34188402",
        //         },
        //         new Article
        //         {
        //             Title = "How to lose weight in 3 weeks!",
        //             Content = "orem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. ",
        //             AuthorId = "864fc7a6-321f-4354-841f-ab5d34188402",
        //         },
        //         new Article
        //         {
        //             Title = "ne znam",
        //             Content = "orem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. ",
        //             AuthorId = "864fc7a6-321f-4354-841f-ab5d34188402",
        //         },
        //         new Article
        //         {
        //             Title = "God's article",
        //             Content = "orem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. ",
        //             AuthorId = "3a80a782-e8cc-4350-a400-ad4287fc3d20",
        //         },
        //     };
        // }
    }
}
