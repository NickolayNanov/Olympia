﻿namespace Olympia.Data.Models.BindingModels.Blogs
{
    using Olympia.Data.Domain;
    using Olympia.Data.Models.ViewModels;
    using System.ComponentModel.DataAnnotations;
    public class CreateCommentBindingModel
    {
    }
}
