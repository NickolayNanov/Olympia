## How to run the project

1. Open the project with Visual Studio 2017 (15.8 or later)
2. Build the project (all packages including the client-side dependencies) will be restored automatically.
