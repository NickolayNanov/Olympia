﻿namespace Olympia.Web.Areas.Identity.Pages.Account
{
    using Microsoft.AspNetCore.Mvc.RazorPages;

#pragma warning disable SA1649 // File name should match first type name
    public class AccessDeniedModel : PageModel
#pragma warning restore SA1649 // File name should match first type name
    {
        public void OnGet()
        {
        }
    }
}
