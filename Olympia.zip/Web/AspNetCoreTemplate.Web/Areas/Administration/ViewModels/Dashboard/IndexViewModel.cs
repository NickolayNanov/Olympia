﻿namespace Olympia.Web.Areas.Administration.ViewModels.Dashboard
{
    public class IndexViewModel
    {
        public int SettingsCount { get; set; }
    }
}
